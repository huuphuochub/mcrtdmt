export interface interfacesize{
    id:number,
    name:string,
    note:string,
}