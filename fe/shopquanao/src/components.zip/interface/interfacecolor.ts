export interface interfacecolor{
    id:number,
    name:string,
}