export interface interfaceProduct{
    id:number;
    name:string;
    image:string;
    idSeller:number;
    describe:string;
    price:number;
    idCategory:number;
    date:Date;
    status:number;
    ratingSum:number;
    ratingCount:number;
    averageRating:number;
    subcategory:number;
    discountprice:number;
    quantity:number;
    totalsold:number;
    weigth:number;
    promo_start:string;
    promo_end:string;
}

export interface Subimginterface {
    id:number,
    product_id:number,
    url:string,
}