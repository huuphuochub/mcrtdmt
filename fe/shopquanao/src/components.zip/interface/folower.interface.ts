export interface Folower{
    id:number;
    seller_id:number;
    user_id:number;
    created_at:string;
}