export interface Commentsellerinterface{
    id:number;
    seller_id:number;
    content:string;
    usser_id:number,
    star:number,
    imageurl:string[];
    createdAt:string;
}