export interface interfacesubimg{
    id:number,
    product_id:number,
    url:string,
}