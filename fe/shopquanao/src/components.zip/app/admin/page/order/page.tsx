import React from "react";

export default function OrderPage(){
    return(
        <div>
            
        </div>
    )
}