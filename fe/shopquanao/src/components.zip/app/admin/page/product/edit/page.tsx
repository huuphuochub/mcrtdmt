import { Editproduct } from "@/app/admin/component/product";
import React from "react";
// import { useParams } from "next/navigation";
export default function EditProduct(){
    //   const { id } = useParams<{ id: string }>();
    //     console.log(id);
        
    return(
        <div>
            <Editproduct/>
        </div>
    )
}