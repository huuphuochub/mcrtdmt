import { Home } from "lucide-react";
import React from "react";
export default function Doasboardadmin(){
    return(
        <div className="m-2">
            <Home/>
        </div>
    )
}

// border border-gray-200 shadow-lg rounded-l