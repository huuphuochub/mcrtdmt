import React from "react";
// import {Headeradmin1,Headeradmin2} from "./component/header";
import HomePageAdmin from "./page/home/home";
export default function Homeadmin(){
    return(
        <div className="">
            
            <HomePageAdmin/>

        </div>
    )
}