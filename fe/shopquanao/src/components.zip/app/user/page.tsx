"use client";

import React from "react";
//  , { useEffect, useState } 


// import { Getuserbyid } from "@/service/userservice";

export default function User() {
  // const [user, setUser] = useState<any>(null); 
  // const [error,setError] =useState('')

  // const fetchUser = async () => {
  //   const result = await Getuserbyid();
  //   if (result) {
  //       console.log(result);
        
  //     setUser(result.data);
  //   }
  // };

  // useEffect(() => {
  //   fetchUser();
  // }, []); // 👈 Thêm dependency rỗng để chỉ gọi 1 lần

  return (
    // <div>
    //   {user ? (
    //     <div>
    //       <p>Tên: {user.username}</p>
    //       <p>SĐT: {user.phone}</p>
    //       {/* Hiển thị thêm thông tin khác nếu muốn */}
    //     </div>
    //   ) : (
    //     <p>Đang tải...</p>
    //   )}
    // </div>
<div>

</div>

  );
}
