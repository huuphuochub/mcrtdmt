import React from "react";

export default function AdminsPage(){
    return(
        <div>
            admins nè
            
        </div>
    )
}